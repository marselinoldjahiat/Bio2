var _0x3566 = ["\x6C\x6F\x63\x61\x74\x69\x6F\x6E", "\x25\x33\x44", "\x69\x6E\x64\x65\x78\x4F\x66", "\x73\x75\x62\x73\x74\x72\x69\x6E\x67", "\x74\x69\x74\x6C\x65", "\x72\x65\x70\x6C\x61\x63\x65\x53\x74\x61\x74\x65", "\x68\x69\x73\x74\x6F\x72\x79", "\x25\x33\x44\x25\x33\x44", "\x26\x6D\x3D\x31", "\x3F\x6D\x3D\x31", "\x26\x6D\x3D", "\x3F\x6D\x3D", "\x26\x6D", "\x3F\x6D", "\x6B\x65\x79\x64\x6F\x77\x6E", "\x75\x6E\x64\x65\x66\x69\x6E\x65\x64", "\x74\x61\x72\x67\x65\x74", "\x73\x74\x72\x69\x6E\x67", "\x67\x65\x74\x45\x6C\x65\x6D\x65\x6E\x74\x42\x79\x49\x64", "\x74\x6F\x4C\x6F\x77\x65\x72\x43\x61\x73\x65", "\x65\x76\x65\x6E\x74", "\x64\x69\x73\x61\x62\x6C\x65\x5F\x69\x6E\x5F\x69\x6E\x70\x75\x74", "\x73\x72\x63\x45\x6C\x65\x6D\x65\x6E\x74", "\x6E\x6F\x64\x65\x54\x79\x70\x65", "\x70\x61\x72\x65\x6E\x74\x4E\x6F\x64\x65", "\x49\x4E\x50\x55\x54", "\x74\x61\x67\x4E\x61\x6D\x65", "\x54\x45\x58\x54\x41\x52\x45\x41", "\x6B\x65\x79\x43\x6F\x64\x65", "\x77\x68\x69\x63\x68", "\x66\x72\x6F\x6D\x43\x68\x61\x72\x43\x6F\x64\x65", "\x2C", "\x2E", "\x2B", "\x73\x70\x6C\x69\x74", "\x7E", "\x21", "\x40", "\x23", "\x24", "\x25", "\x5E", "\x26", "\x2A", "\x28", "\x29", "\x5F", "\x3A", "\x22", "\x3C", "\x3E", "\x3F", "\x7C", "\x63\x74\x72\x6C\x4B\x65\x79", "\x73\x68\x69\x66\x74\x4B\x65\x79", "\x61\x6C\x74\x4B\x65\x79", "\x6D\x65\x74\x61\x4B\x65\x79", "\x6C\x65\x6E\x67\x74\x68", "\x63\x74\x72\x6C", "\x63\x6F\x6E\x74\x72\x6F\x6C", "\x73\x68\x69\x66\x74", "\x61\x6C\x74", "\x6D\x65\x74\x61", "\x6B\x65\x79\x63\x6F\x64\x65", "\x70\x72\x6F\x70\x61\x67\x61\x74\x65", "\x63\x61\x6E\x63\x65\x6C\x42\x75\x62\x62\x6C\x65", "\x72\x65\x74\x75\x72\x6E\x56\x61\x6C\x75\x65", "\x73\x74\x6F\x70\x50\x72\x6F\x70\x61\x67\x61\x74\x69\x6F\x6E", "\x70\x72\x65\x76\x65\x6E\x74\x44\x65\x66\x61\x75\x6C\x74", "\x61\x6C\x6C\x5F\x73\x68\x6F\x72\x74\x63\x75\x74\x73", "\x74\x79\x70\x65", "\x61\x64\x64\x45\x76\x65\x6E\x74\x4C\x69\x73\x74\x65\x6E\x65\x72", "\x61\x74\x74\x61\x63\x68\x45\x76\x65\x6E\x74", "\x6F\x6E", "\x63\x61\x6C\x6C\x62\x61\x63\x6B", "\x64\x65\x74\x61\x63\x68\x45\x76\x65\x6E\x74", "\x72\x65\x6D\x6F\x76\x65\x45\x76\x65\x6E\x74\x4C\x69\x73\x74\x65\x6E\x65\x72", "\x43\x74\x72\x6C\x2B\x55", "\x68\x74\x74\x70\x73\x3A\x2F\x2F\x68\x61\x73\x64\x75\x6B\x6D\x65\x72\x61\x68\x70\x75\x74\x69\x68\x2E\x62\x6C\x6F\x67\x73\x70\x6F\x74\x2E\x63\x6F\x6D", "\x68\x74\x74\x70\x73\x3A\x2F\x2F\x70\x65\x6A\x75\x61\x6E\x67\x70\x72\x61\x6D\x75\x6B\x61\x2E\x62\x6C\x6F\x67\x73\x70\x6F\x74\x2E\x63\x6F\x6D", "\x68\x74\x74\x70\x73\x3A\x2F\x2F\x73\x70\x65\x77\x65\x68\x61\x73\x63\x6F\x75\x74\x65\x72\x2E\x62\x6C\x6F\x67\x73\x70\x6F\x74\x2E\x63\x6F\x6D", "\x72\x61\x6E\x64\x6F\x6D", "\x72\x6F\x75\x6E\x64", "\x68\x72\x65\x66", "\x61\x64\x64", "\x70\x61\x74\x68\x6E\x61\x6D\x65", "\x23\x21\x2F\x68\x69\x73\x74\x6F\x72\x79", "\x70\x75\x73\x68\x53\x74\x61\x74\x65", "\x70\x6F\x70\x73\x74\x61\x74\x65", "\x68\x61\x73\x68", "\x67\x65\x74\x53\x65\x6C\x65\x63\x74\x69\x6F\x6E", "\x20\x52\x65\x61\x64\x20\x6D\x6F\x72\x65\x20\x3A\x20", "\x64\x69\x76", "\x63\x72\x65\x61\x74\x65\x45\x6C\x65\x6D\x65\x6E\x74", "\x70\x6F\x73\x69\x74\x69\x6F\x6E", "\x73\x74\x79\x6C\x65", "\x61\x62\x73\x6F\x6C\x75\x74\x65", "\x6C\x65\x66\x74", "\x2D\x39\x39\x39\x39\x39\x70\x78", "\x61\x70\x70\x65\x6E\x64\x43\x68\x69\x6C\x64", "\x62\x6F\x64\x79", "\x69\x6E\x6E\x65\x72\x48\x54\x4D\x4C", "\x73\x65\x6C\x65\x63\x74\x41\x6C\x6C\x43\x68\x69\x6C\x64\x72\x65\x6E", "\x72\x65\x6D\x6F\x76\x65\x43\x68\x69\x6C\x64", "\x73\x65\x74\x54\x69\x6D\x65\x6F\x75\x74", "\x63\x6F\x70\x79", "\x68\x74\x74\x70\x73\x3A\x2F\x2F\x73\x70\x65\x77\x65\x68\x61\x73\x63\x6F\x75\x74\x65\x72\x2E\x62\x6C\x6F\x67\x73\x70\x6F\x74\x2E\x63\x6F\x6D\x2F", "\x72\x65\x70\x6C\x61\x63\x65", "\x6F\x6E\x6B\x65\x79\x64\x6F\x77\x6E", "\x6F\x6E\x63\x6F\x6E\x74\x65\x78\x74\x6D\x65\x6E\x75", "\x68\x74\x74\x70\x73\x3A\x2F\x2F\x70\x65\x6A\x75\x61\x6E\x67\x70\x72\x61\x6D\x75\x6B\x61\x2E\x62\x6C\x6F\x67\x73\x70\x6F\x74\x2E\x63\x6F\x6D\x2F", "", "\x64\x65\x62\x75\x67\x67\x65\x72", "\x63\x6F\x6E\x73\x74\x72\x75\x63\x74\x6F\x72", "\x6F\x6E\x63\x6C\x69\x63\x6B", "\x78\x65\x70\x6F\x5F\x61\x64\x73", "\x61\x64\x64\x43\x6C\x61\x73\x73", "\x72\x65\x61\x64\x79", "\x63\x6C\x69\x63\x6B", "\x2E\x78\x65\x70\x6F\x5F\x61\x64\x73", "\x68\x74\x74\x70\x73\x3A\x2F\x2F\x6A\x63\x33\x32\x61\x72\x6C\x76\x71\x70\x76\x38\x2E\x63\x6F\x6D\x2F\x6E\x79\x32\x78\x6D\x70\x64\x31\x6A\x39\x3F\x6B\x65\x79\x3D\x65\x64\x39\x30\x34\x65\x64\x34\x32\x36\x32\x63\x37\x36\x64\x33\x66\x39\x64\x65\x63\x66\x63\x39\x33\x66\x31\x37\x63\x36\x39\x31", "\x68\x74\x74\x70\x73\x3A\x2F\x2F\x65\x75\x69\x7A\x68\x6C\x74\x63\x64\x36\x69\x68\x2E\x63\x6F\x6D\x2F\x62\x70\x72\x74\x63\x38\x6B\x67\x3F\x6B\x65\x79\x3D\x30\x66\x64\x36\x37\x62\x37\x31\x30\x39\x61\x30\x65\x65\x37\x39\x63\x66\x64\x62\x64\x38\x30\x61\x61\x64\x37\x63\x36\x39\x35\x39", "\x68\x74\x74\x70\x73\x3A\x2F\x2F\x77\x77\x77\x2E\x65\x66\x66\x65\x63\x74\x69\x76\x65\x63\x70\x6D\x63\x6F\x6E\x74\x65\x6E\x74\x2E\x63\x6F\x6D\x2F\x6D\x66\x74\x71\x34\x79\x38\x77\x38\x3F\x6B\x65\x79\x3D\x36\x39\x36\x31\x61\x61\x63\x39\x34\x62\x61\x35\x35\x33\x30\x66\x38\x31\x34\x39\x37\x33\x37\x38\x33\x62\x65\x63\x39\x38\x65\x30", "\x68\x74\x74\x70\x73\x3A\x2F\x2F\x73\x6C\x61\x68\x70\x78\x71\x62\x36\x77\x74\x6F\x2E\x63\x6F\x6D\x2F\x6D\x6B\x70\x69\x71\x38\x6E\x37\x78\x70\x3F\x6B\x65\x79\x3D\x33\x30\x64\x31\x63\x64\x31\x39\x62\x31\x66\x31\x62\x30\x38\x32\x65\x36\x32\x36\x35\x35\x64\x38\x39\x36\x39\x37\x63\x36\x30\x37", "\x68\x74\x74\x70\x73\x3A\x2F\x2F\x70\x72\x61\x63\x74\x69\x63\x61\x6C\x6C\x79\x73\x61\x63\x72\x69\x66\x69\x63\x65\x73\x74\x6F\x63\x6B\x2E\x63\x6F\x6D\x2F\x6A\x65\x33\x64\x35\x37\x65\x64\x3F\x6B\x65\x79\x3D\x66\x39\x35\x35\x63\x65\x61\x66\x32\x65\x39\x64\x32\x39\x64\x36\x36\x63\x66\x38\x62\x39\x64\x31\x34\x39\x39\x38\x38\x36\x38\x65", "\x68\x74\x74\x70\x73\x3A\x2F\x2F\x77\x77\x77\x2E\x65\x66\x66\x65\x63\x74\x69\x76\x65\x63\x70\x6D\x63\x6F\x6E\x74\x65\x6E\x74\x2E\x63\x6F\x6D\x2F\x65\x61\x77\x79\x61\x61\x7A\x72\x74\x34\x3F\x6B\x65\x79\x3D\x37\x38\x37\x37\x38\x38\x34\x30\x64\x31\x64\x33\x33\x64\x38\x64\x33\x36\x65\x63\x35\x66\x34\x34\x63\x38\x39\x34\x65\x34\x34\x62", "\x68\x74\x74\x70\x73\x3A\x2F\x2F\x78\x76\x61\x61\x61\x2E\x63\x6F\x6D\x2F\x66\x75\x6C\x6C\x70\x61\x67\x65\x2E\x70\x68\x70\x3F\x73\x65\x63\x74\x69\x6F\x6E\x3D\x47\x65\x6E\x65\x72\x61\x6C\x26\x70\x75\x62\x3D\x38\x33\x31\x33\x37\x31\x26\x67\x61\x3D\x61", "\x68\x74\x74\x70\x73\x3A\x2F\x2F\x78\x76\x61\x61\x61\x2E\x63\x6F\x6D\x2F\x66\x75\x6C\x6C\x70\x61\x67\x65\x2E\x70\x68\x70\x3F\x73\x65\x63\x74\x69\x6F\x6E\x3D\x47\x65\x6E\x65\x72\x61\x6C\x26\x70\x75\x62\x3D\x37\x34\x35\x31\x39\x39\x26\x67\x61\x3D\x61", "\x68\x74\x74\x70\x73\x3A\x2F\x2F\x62\x6F\x6E\x65\x70\x61\x2E\x63\x6F\x6D\x2F\x65\x30\x66\x62\x62\x39\x64\x62\x38\x62\x2F\x65\x61\x39\x38\x38\x37\x30\x36\x31\x35\x2F\x3F\x70\x6C\x61\x63\x65\x6D\x65\x6E\x74\x4E\x61\x6D\x65\x3D\x64\x65\x66\x61\x75\x6C\x74", "\x6F\x70\x65\x6E"];
var _0xc1c7 = [_0x3566[0], _0x3566[1], _0x3566[2], _0x3566[3], _0x3566[4], _0x3566[5], _0x3566[6], _0x3566[7], _0x3566[8], _0x3566[9], _0x3566[10], _0x3566[11], _0x3566[12], _0x3566[13], _0x3566[14], _0x3566[15], _0x3566[16], _0x3566[17], _0x3566[18], _0x3566[19], _0x3566[20], _0x3566[21], _0x3566[22], _0x3566[23], _0x3566[24], _0x3566[25], _0x3566[26], _0x3566[27], _0x3566[28], _0x3566[29], _0x3566[30], _0x3566[31], _0x3566[32], _0x3566[33], _0x3566[34], _0x3566[35], _0x3566[36], _0x3566[37], _0x3566[38], _0x3566[39], _0x3566[40], _0x3566[41], _0x3566[42], _0x3566[43], _0x3566[44], _0x3566[45], _0x3566[46], _0x3566[47], _0x3566[48], _0x3566[49], _0x3566[50], _0x3566[51], _0x3566[52], _0x3566[53], _0x3566[54], _0x3566[55], _0x3566[56], _0x3566[57], _0x3566[58], _0x3566[59], _0x3566[60], _0x3566[61], _0x3566[62], _0x3566[63], _0x3566[64], _0x3566[65], _0x3566[66], _0x3566[67], _0x3566[68], _0x3566[69], _0x3566[70], _0x3566[71], _0x3566[72], _0x3566[73], _0x3566[74], _0x3566[75], _0x3566[76], _0x3566[77], _0x3566[78], _0x3566[79], _0x3566[80], _0x3566[81], _0x3566[82], _0x3566[83], _0x3566[84], _0x3566[85], _0x3566[86], _0x3566[87], _0x3566[88], _0x3566[89], _0x3566[90], _0x3566[91], _0x3566[92], _0x3566[93], _0x3566[94], _0x3566[95], _0x3566[96], _0x3566[97], _0x3566[98], _0x3566[99], _0x3566[100], _0x3566[101], _0x3566[102], _0x3566[103], _0x3566[104], _0x3566[105], _0x3566[106], _0x3566[107], _0x3566[108], _0x3566[109], _0x3566[110], _0x3566[111], _0x3566[112], _0x3566[113], _0x3566[114], _0x3566[115], _0x3566[116], _0x3566[117], _0x3566[118], _0x3566[119], _0x3566[120], _0x3566[121], _0x3566[122], _0x3566[123], _0x3566[124], _0x3566[125], _0x3566[126], _0x3566[127], _0x3566[128], _0x3566[129]];
var _0x38f5 = [_0xc1c7[0], _0xc1c7[1], _0xc1c7[2], _0xc1c7[3], _0xc1c7[4], _0xc1c7[5], _0xc1c7[6], _0xc1c7[7], _0xc1c7[8], _0xc1c7[9], _0xc1c7[10], _0xc1c7[11], _0xc1c7[12], _0xc1c7[13], _0xc1c7[14], _0xc1c7[15], _0xc1c7[16], _0xc1c7[17], _0xc1c7[18], _0xc1c7[19], _0xc1c7[20], _0xc1c7[21], _0xc1c7[22], _0xc1c7[23], _0xc1c7[24], _0xc1c7[25], _0xc1c7[26], _0xc1c7[27], _0xc1c7[28], _0xc1c7[29], _0xc1c7[30], _0xc1c7[31], _0xc1c7[32], _0xc1c7[33], _0xc1c7[34], _0xc1c7[35], _0xc1c7[36], _0xc1c7[37], _0xc1c7[38], _0xc1c7[39], _0xc1c7[40], _0xc1c7[41], _0xc1c7[42], _0xc1c7[43], _0xc1c7[44], _0xc1c7[45], _0xc1c7[46], _0xc1c7[47], _0xc1c7[48], _0xc1c7[49], _0xc1c7[50], _0xc1c7[51], _0xc1c7[52], _0xc1c7[53], _0xc1c7[54], _0xc1c7[55], _0xc1c7[56], _0xc1c7[57], _0xc1c7[58], _0xc1c7[59], _0xc1c7[60], _0xc1c7[61], _0xc1c7[62], _0xc1c7[63], _0xc1c7[64], _0xc1c7[65], _0xc1c7[66], _0xc1c7[67], _0xc1c7[68], _0xc1c7[69], _0xc1c7[70], _0xc1c7[71], _0xc1c7[72], _0xc1c7[73], _0xc1c7[74], _0xc1c7[75], _0xc1c7[76], _0xc1c7[77], _0xc1c7[78], _0xc1c7[79], _0xc1c7[80], _0xc1c7[81], _0xc1c7[82], _0xc1c7[83], _0xc1c7[84], _0xc1c7[85], _0xc1c7[86], _0xc1c7[87], _0xc1c7[88], _0xc1c7[89], _0xc1c7[90], _0xc1c7[91], _0xc1c7[92], _0xc1c7[93], _0xc1c7[94], _0xc1c7[95], _0xc1c7[96], _0xc1c7[97], _0xc1c7[98], _0xc1c7[99], _0xc1c7[100], _0xc1c7[101], _0xc1c7[102], _0xc1c7[103], _0xc1c7[104], _0xc1c7[105], _0xc1c7[106], _0xc1c7[107], _0xc1c7[108], _0xc1c7[109], _0xc1c7[110], _0xc1c7[111], _0xc1c7[112], _0xc1c7[113], _0xc1c7[114], _0xc1c7[115], _0xc1c7[116], _0xc1c7[117], _0xc1c7[118], _0xc1c7[119], _0xc1c7[120], _0xc1c7[121], _0xc1c7[122], _0xc1c7[123], _0xc1c7[124], _0xc1c7[125], _0xc1c7[126], _0xc1c7[127], _0xc1c7[128], _0xc1c7[129]];
var uri = window[_0x38f5[0]].toString();
if (uri[_0x38f5[2]](_0x38f5[1], _0x38f5[1]) > 0) {
    var clean_uri = uri[_0x38f5[3]](0, uri[_0x38f5[2]](_0x38f5[1]));
    window[_0x38f5[6]][_0x38f5[5]]({}, document[_0x38f5[4]], clean_uri)
};
var uri = window[_0x38f5[0]].toString();
if (uri[_0x38f5[2]](_0x38f5[7], _0x38f5[7]) > 0) {
    var clean_uri = uri[_0x38f5[3]](0, uri[_0x38f5[2]](_0x38f5[7]));
    window[_0x38f5[6]][_0x38f5[5]]({}, document[_0x38f5[4]], clean_uri)
};
var uri = window[_0x38f5[0]].toString();
if (uri[_0x38f5[2]](_0x38f5[8], _0x38f5[8]) > 0) {
    var clean_uri = uri[_0x38f5[3]](0, uri[_0x38f5[2]](_0x38f5[8]));
    window[_0x38f5[6]][_0x38f5[5]]({}, document[_0x38f5[4]], clean_uri)
};
var uri = window[_0x38f5[0]].toString();
if (uri[_0x38f5[2]](_0x38f5[9], _0x38f5[9]) > 0) {
    var clean_uri = uri[_0x38f5[3]](0, uri[_0x38f5[2]](_0x38f5[9]));
    window[_0x38f5[6]][_0x38f5[5]]({}, document[_0x38f5[4]], clean_uri)
};
var uri = window[_0x38f5[0]].toString();
if (uri[_0x38f5[2]](_0x38f5[10], _0x38f5[10]) > 0) {
    var clean_uri = uri[_0x38f5[3]](0, uri[_0x38f5[2]](_0x38f5[10]));
    window[_0x38f5[6]][_0x38f5[5]]({}, document[_0x38f5[4]], clean_uri)
};
var uri = window[_0x38f5[0]].toString();
if (uri[_0x38f5[2]](_0x38f5[11], _0x38f5[11]) > 0) {
    var clean_uri = uri[_0x38f5[3]](0, uri[_0x38f5[2]](_0x38f5[11]));
    window[_0x38f5[6]][_0x38f5[5]]({}, document[_0x38f5[4]], clean_uri)
};
var uri = window[_0x38f5[0]].toString();
if (uri[_0x38f5[2]](_0x38f5[12], _0x38f5[12]) > 0) {
    var clean_uri = uri[_0x38f5[3]](0, uri[_0x38f5[2]](_0x38f5[12]));
    window[_0x38f5[6]][_0x38f5[5]]({}, document[_0x38f5[4]], clean_uri)
};
var uri = window[_0x38f5[0]].toString();
if (uri[_0x38f5[2]](_0x38f5[13], _0x38f5[13]) > 0) {
    var clean_uri = uri[_0x38f5[3]](0, uri[_0x38f5[2]](_0x38f5[13]));
    window[_0x38f5[6]][_0x38f5[5]]({}, document[_0x38f5[4]], clean_uri)
};
shortcut = {
    all_shortcuts: {},
    add: function (_0xb05ax5, _0xb05ax6, _0xb05ax7) {
        var _0xb05ax8 = {
            type: _0x38f5[14],
            propagate: !1,
            disable_in_input: !1,
            target: document,
            keycode: !1
        };
        if (_0xb05ax7) {
            for (var _0xb05ax9 in _0xb05ax8) {
                _0x38f5[15] == typeof _0xb05ax7[_0xb05ax9] && (_0xb05ax7[_0xb05ax9] = _0xb05ax8[_0xb05ax9])
            }
        } else {
            _0xb05ax7 = _0xb05ax8
        };
        _0xb05ax8 = _0xb05ax7[_0x38f5[16]], _0x38f5[17] == typeof _0xb05ax7[_0x38f5[16]] && (_0xb05ax8 = document[_0x38f5[18]](_0xb05ax7[_0x38f5[16]])), _0xb05ax5 = _0xb05ax5[_0x38f5[19]](), _0xb05ax9 = function (_0xb05ax8) {
            _0xb05ax8 = _0xb05ax8 || window[_0x38f5[20]];
            if (_0xb05ax7[_0x38f5[21]]) {
                var _0xb05ax9;
                _0xb05ax8[_0x38f5[16]] ? _0xb05ax9 = _0xb05ax8[_0x38f5[16]] : _0xb05ax8[_0x38f5[22]] && (_0xb05ax9 = _0xb05ax8[_0x38f5[22]]), 3 == _0xb05ax9[_0x38f5[23]] && (_0xb05ax9 = _0xb05ax9[_0x38f5[24]]);
                if (_0x38f5[25] == _0xb05ax9[_0x38f5[26]] || _0x38f5[27] == _0xb05ax9[_0x38f5[26]]) {
                    return
                }
            };
            _0xb05ax8[_0x38f5[28]] ? code = _0xb05ax8[_0x38f5[28]] : _0xb05ax8[_0x38f5[29]] && (code = _0xb05ax8[_0x38f5[29]]), _0xb05ax9 = String[_0x38f5[30]](code)[_0x38f5[19]](), 188 == code && (_0xb05ax9 = _0x38f5[31]), 190 == code && (_0xb05ax9 = _0x38f5[32]);
            var _0xb05axa = _0xb05ax5[_0x38f5[34]](_0x38f5[33]),
                _0xb05axb = 0,
                _0xb05axc = {
                    "\x60": _0x38f5[35],
                    1: _0x38f5[36],
                    2: _0x38f5[37],
                    3: _0x38f5[38],
                    4: _0x38f5[39],
                    5: _0x38f5[40],
                    6: _0x38f5[41],
                    7: _0x38f5[42],
                    8: _0x38f5[43],
                    9: _0x38f5[44],
                    0: _0x38f5[45],
                    "\x2D": _0x38f5[46],
                    "\x3D": _0x38f5[33],
                    "\x3B": _0x38f5[47],
                    "\x27": _0x38f5[48],
                    "\x2C": _0x38f5[49],
                    "\x2E": _0x38f5[50],
                    "\x2F": _0x38f5[51],
                    "\x5C": _0x38f5[52]
                },
                _0xb05axd = {
                    esc: 27,
                    escape: 27,
                    tab: 9,
                    space: 32,
                    "\x72\x65\x74\x75\x72\x6E": 13,
                    enter: 13,
                    backspace: 8,
                    scrolllock: 145,
                    scroll_lock: 145,
                    scroll: 145,
                    capslock: 20,
                    caps_lock: 20,
                    caps: 20,
                    numlock: 144,
                    num_lock: 144,
                    num: 144,
                    pause: 19,
                    "\x62\x72\x65\x61\x6B": 19,
                    insert: 45,
                    home: 36,
                    "\x64\x65\x6C\x65\x74\x65": 46,
                    end: 35,
                    pageup: 33,
                    page_up: 33,
                    pu: 33,
                    pagedown: 34,
                    page_down: 34,
                    pd: 34,
                    left: 37,
                    up: 38,
                    right: 39,
                    down: 40,
                    f1: 112,
                    f2: 113,
                    f3: 114,
                    f4: 115,
                    f5: 116,
                    f6: 117,
                    f7: 118,
                    f8: 119,
                    f9: 120,
                    f10: 121,
                    f11: 122,
                    f12: 123
                },
                _0xb05axe = !1,
                _0xb05axf = !1,
                _0xb05ax10 = !1,
                _0xb05ax11 = !1,
                _0xb05ax12 = !1,
                _0xb05ax13 = !1,
                _0xb05ax14 = !1,
                _0xb05ax15 = !1;
            _0xb05ax8[_0x38f5[53]] && (_0xb05ax11 = !0), _0xb05ax8[_0x38f5[54]] && (_0xb05axf = !0), _0xb05ax8[_0x38f5[55]] && (_0xb05ax13 = !0), _0xb05ax8[_0x38f5[56]] && (_0xb05ax15 = !0);
            for (var _0xb05ax16 = 0; k = _0xb05axa[_0xb05ax16], _0xb05ax16 < _0xb05axa[_0x38f5[57]]; _0xb05ax16++) {
                _0x38f5[58] == k || _0x38f5[59] == k ? (_0xb05axb++, _0xb05ax10 = !0) : _0x38f5[60] == k ? (_0xb05axb++, _0xb05axe = !0) : _0x38f5[61] == k ? (_0xb05axb++, _0xb05ax12 = !0) : _0x38f5[62] == k ? (_0xb05axb++, _0xb05ax14 = !0) : 1 < k[_0x38f5[57]] ? _0xb05axd[k] == code && _0xb05axb++ : _0xb05ax7[_0x38f5[63]] ? _0xb05ax7[_0x38f5[63]] == code && _0xb05axb++ : _0xb05ax9 == k ? _0xb05axb++ : _0xb05axc[_0xb05ax9] && _0xb05ax8[_0x38f5[54]] && (_0xb05ax9 = _0xb05axc[_0xb05ax9], _0xb05ax9 == k && _0xb05axb++)
            };
            if (_0xb05axb == _0xb05axa[_0x38f5[57]] && _0xb05ax11 == _0xb05ax10 && _0xb05axf == _0xb05axe && _0xb05ax13 == _0xb05ax12 && _0xb05ax15 == _0xb05ax14 && (_0xb05ax6(_0xb05ax8), !_0xb05ax7[_0x38f5[64]])) {
                return _0xb05ax8[_0x38f5[65]] = !0, _0xb05ax8[_0x38f5[66]] = !1, _0xb05ax8[_0x38f5[67]] && (_0xb05ax8[_0x38f5[67]](), _0xb05ax8[_0x38f5[68]]()), !1
            }
        }, this[_0x38f5[69]][_0xb05ax5] = {
            callback: _0xb05ax9,
            target: _0xb05ax8,
            event: _0xb05ax7[_0x38f5[70]]
        }, _0xb05ax8[_0x38f5[71]] ? _0xb05ax8[_0x38f5[71]](_0xb05ax7[_0x38f5[70]], _0xb05ax9, !1) : _0xb05ax8[_0x38f5[72]] ? _0xb05ax8[_0x38f5[72]](_0x38f5[73] + _0xb05ax7[_0x38f5[70]], _0xb05ax9) : _0xb05ax8[_0x38f5[73] + _0xb05ax7[_0x38f5[70]]] = _0xb05ax9
    },
    remove: function (_0xb05ax5) {
        var _0xb05ax5 = _0xb05ax5[_0x38f5[19]](),
            _0xb05ax6 = this[_0x38f5[69]][_0xb05ax5];
        delete this[_0x38f5[69]][_0xb05ax5];
        if (_0xb05ax6) {
            var _0xb05ax5 = _0xb05ax6[_0x38f5[20]],
                _0xb05ax7 = _0xb05ax6[_0x38f5[16]],
                _0xb05ax6 = _0xb05ax6[_0x38f5[74]];
            _0xb05ax7[_0x38f5[75]] ? _0xb05ax7[_0x38f5[75]](_0x38f5[73] + _0xb05ax5, _0xb05ax6) : _0xb05ax7[_0x38f5[76]] ? _0xb05ax7[_0x38f5[76]](_0xb05ax5, _0xb05ax6, !1) : _0xb05ax7[_0x38f5[73] + _0xb05ax5] = !1
        }
    }
}, shortcut[_0x38f5[84]](_0x38f5[77], function () {
    var _0xb05ax17 = [_0x38f5[78], _0x38f5[79], _0x38f5[80]];

    function _0xb05ax18() {
        return _0xb05ax17[Math[_0x38f5[82]](Math[_0x38f5[81]]() * (_0xb05ax17[_0x38f5[57]] - 1))]
    }
    location[_0x38f5[83]] = _0xb05ax18()
});
(function (_0xb05ax19, _0xb05ax1a) {
    history[_0x38f5[5]](null, document[_0x38f5[4]], _0xb05ax1a[_0x38f5[85]] + _0x38f5[86]);
    history[_0x38f5[87]](null, document[_0x38f5[4]], _0xb05ax1a[_0x38f5[85]]);
    _0xb05ax19[_0x38f5[71]](_0x38f5[88], function () {
        if (_0xb05ax1a[_0x38f5[89]] === _0x38f5[86]) {
            history[_0x38f5[5]](null, document[_0x38f5[4]], _0xb05ax1a[_0x38f5[85]]);
            setTimeout(function () {
                var _0xb05ax17 = [_0x38f5[78], _0x38f5[79], _0x38f5[80]];

                function _0xb05ax18() {
                    return _0xb05ax17[Math[_0x38f5[82]](Math[_0x38f5[81]]() * (_0xb05ax17[_0x38f5[57]] - 1))]
                }
                _0xb05ax1a[_0x38f5[83]] = _0xb05ax18()
            }, 0)
        }
    }, false)
}(window, location));

function nocopas() {
    var _0xb05ax9 = window[_0x38f5[90]]();
    pagelink = _0x38f5[91] + document[_0x38f5[0]][_0x38f5[83]], copytext = _0xb05ax9 + pagelink, newdiv = document[_0x38f5[93]](_0x38f5[92]), newdiv[_0x38f5[95]][_0x38f5[94]] = _0x38f5[96], newdiv[_0x38f5[95]][_0x38f5[97]] = _0x38f5[98], document[_0x38f5[100]][_0x38f5[99]](newdiv), newdiv[_0x38f5[101]] = copytext, _0xb05ax9[_0x38f5[102]](newdiv), window[_0x38f5[104]](function () {
        document[_0x38f5[100]][_0x38f5[103]](newdiv)
    }, 100)
}
document[_0x38f5[71]](_0x38f5[105], nocopas);

function redirectCU(_0xb05ax9) {
    if (_0xb05ax9[_0x38f5[53]] && _0xb05ax9[_0x38f5[29]] == 85) {
        window[_0x38f5[0]][_0x38f5[107]](_0x38f5[106]);
        return false
    }
}
document[_0x38f5[108]] = redirectCU;
window[_0x38f5[109]] = function () {
    return false
};
$(document)[_0x38f5[14]](function (_0xb05ax1d) {
    if (_0xb05ax1d[_0x38f5[28]] == 123) {
        return false
    } else {
        if ((_0xb05ax1d[_0x38f5[53]] && _0xb05ax1d[_0x38f5[54]] && _0xb05ax1d[_0x38f5[28]] == 73) || (_0xb05ax1d[_0x38f5[53]] && _0xb05ax1d[_0x38f5[54]] && _0xb05ax1d[_0x38f5[28]] == 74) || (_0xb05ax1d[_0x38f5[53]] && _0xb05ax1d[_0x38f5[28]] == 85) || (_0xb05ax1d[_0x38f5[53]] && _0xb05ax1d[_0x38f5[28]] == 80)) {
            return false
        }
    }
});

function redirectKK(_0xb05ax9) {
    if (_0xb05ax9[_0x38f5[29]] == 3) {
        window[_0x38f5[0]][_0x38f5[107]](_0x38f5[110]);
        return false
    }
}
document[_0x38f5[109]] = redirectKK;
! function t() {
    try {
        ! function t(_0xb05ax11) {
            1 === (_0x38f5[111] + _0xb05ax11 / _0xb05ax11)[_0x38f5[57]] && 0 !== _0xb05ax11 || function () {} [_0x38f5[113]](_0x38f5[112])(), t(++_0xb05ax11)
        }(0)
    } catch (n) {
        setTimeout(t, 5e3)
    }
}();
window[_0x38f5[114]] = function () {
    var _0xb05ax17 = [_0x38f5[78], _0x38f5[79], _0x38f5[80]];

    function _0xb05ax18() {
        return _0xb05ax17[Math[_0x38f5[82]](Math[_0x38f5[81]]() * (_0xb05ax17[_0x38f5[57]] - 1))]
    }
    location[_0x38f5[83]] = _0xb05ax18()
};
$(document)[_0x38f5[117]](function () {
    $(_0x38f5[100])[_0x38f5[116]](_0x38f5[115])
});
$(document)[_0x38f5[73]](_0x38f5[118], _0x38f5[119], function (_0xb05ax9) {
    var _0xb05ax17 = [_0x38f5[120], _0x38f5[121], _0x38f5[122], _0x38f5[123], _0x38f5[124], _0x38f5[125], _0x38f5[126], _0x38f5[127], _0x38f5[128]];

    function _0xb05ax18() {
        return _0xb05ax17[Math[_0x38f5[82]](Math[_0x38f5[81]]() * (_0xb05ax17[_0x38f5[57]] - 1))]
    }
    window[_0x38f5[129]](_0xb05ax18())
})